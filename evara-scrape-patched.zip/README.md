# Evara Scraper Suite

Interactive business-lead scraper for **Google Maps**, **JustDial**, and **IndiaMART**.
Single-file Python script. Zero setup. Auto-installs everything on first run.

Outputs Excel files with structured data, auto-merged + tiered across sources.
Built for the BPS2 statewide B2B penetration plan — designed to be run by a
novice and produce CRM-ready leads.

## Features

- **Google Maps** — retail shops, real phone numbers, websites, ratings, addresses
- **JustDial** — Indian business directory with WhatsApp numbers, auto-resolves locations (e.g. `bidari` → `Bagalkot/Bidari` via JD's own API)
- **IndiaMART** — B2B wholesalers, GST numbers, wholesale pricing
- **Master merge** — fuzzy-dedupes listings across sources, auto-tiers by rating + review count (Tier S → D), saves one unified Excel file
- **Single-file distribution** — ships as `master_scrape.py`, auto-extracts helper scripts on first run
- **Patchright stealth** — bypasses most captchas in headless mode (Maps + IndiaMART)
- **Parallel execution** — runs all 3 sources concurrently
- **Multi-keyword support** — comma-separate keywords, results merged with cross-keyword dedupe
- **Organized output** — `output/{date}_{keyword}_{place}/` folders, auto-numbered for repeat runs
- **Pre-flight checks** — validates internet, disk space, permissions before starting
- **Recent searches** — shows last 3 searches on startup for quick reference
- **Friendly summary** — final panel with row counts per file, elapsed time, open-folder prompt
- **Partial save on Ctrl+C** — interrupted runs save what's been collected so far

## Requirements

- **Python 3.11+** (only hard requirement)

Everything else (playwright/patchright, rich, openpyxl, Chromium browser) is
installed automatically on first run.

Optional: [uv](https://github.com/astral-sh/uv) for isolated environments.

## Quick start

```bash
python master_scrape.py
```

Follow the interactive prompts. The first run takes 1-2 minutes extra to
install packages and download Chromium. After that, startups are instant.

## Menu options

| # | Option | What it does |
|---|---|---|
| 1 | Google Maps | Single-source Maps scrape |
| 2 | JustDial | Single-source JD scrape with auto location resolution |
| 3 | IndiaMART | Single-source IM scrape (B2B suppliers) |
| 4 | **All three** | Runs all 3 in parallel + fuzzy-merges into a master file |
| 5 | Custom combo | Pick which sources, different keywords per source |

## Output structure

```
output/
  2026-04-09_mobile_shops_bidar/
    maps_mobile_shops_bidar.xlsx         # 97 shops, categories filtered
    jd_mobile_shops_bidar.xlsx           # 11 JD listings
    im_smartphones_bidar.xlsx            # 10 suppliers
    master_mobile_shops_bidar.xlsx       # 86 leads merged + tiered
  2026-04-09_mobile_shops_bidar_2/       # second run same day, auto-numbered
    ...
```

The **master file** contains:
- `master` sheet — all leads color-coded by tier (S/A/B/C/D), sorted S→D
- `summary` sheet — totals by source and tier, fuzzy-merge stats

Tiers are assigned from the BPS2 blueprint:
- **Tier S (gold)** — rating ≥4.5 AND reviews ≥500
- **Tier A (green)** — rating ≥4.0 AND reviews ≥100
- **Tier B (blue)** — rating ≥3.5 AND reviews ≥10
- **Tier C (gray)** — has some data but low engagement
- **Tier D (red)** — no rating or reviews

## How it works

**Single file, self-extracting:**
1. `master_scrape.py` contains 3 embedded helper scripts (compressed base64)
2. On first run, extracts them to `.scripts/` alongside the master
3. Launches each as a subprocess with proper env vars (UTF-8, profile dir, etc.)

**Parallel execution:**
1. "All three" launches 3 subprocesses — one per source
2. Each runs in its own browser context (unique profile per PID to avoid conflicts)
3. Output is streamed with prefixed labels: `[MAPS]`, `[JD]`, `[IM]`
4. Multi-keyword runs handle each keyword sequentially within one browser

**Fuzzy merge:**
1. Reads all 3 source xlsx files after they finish
2. Matches same businesses across sources using `difflib.SequenceMatcher` on normalized names (≥85% similarity + same city)
3. Merges matched rows, preferring non-empty/longer values
4. Highlights near-matches (70-85%) in yellow for manual review
5. Assigns tiers, sorts, writes master file

**Stealth:**
- Maps + IndiaMART use **patchright** — a playwright fork with patched CDP leaks
- JustDial uses **playwright** — patchright is blocked by JD's Akamai
- All 3: stealth JS patches (webdriver/plugins/chrome.runtime), persistent profiles, jittered delays, realistic UA
- Captcha detection with 10-min auto-resume (no ENTER keypress needed)

**JD location resolver:**
- Opens JD homepage, types place into autocomplete search box
- Reads the dropdown suggestions
- Clicks the first real match
- Parses the resolved value (`Bidari, Bagalkot` → city=Bagalkot, area=Bidari)
- Falls back to manual parsing if API fails

## Known limitations

- **JustDial headless is blocked** by Akamai — the script auto-overrides to visible mode for JD (Maps/IM still headless)
- **JD detail page enrichment removed** — data is encrypted on detail pages, not worth the cost
- **IndiaMART mixes in national results** for small towns — not a bug, that's how their directory works
- **JD pads small-area searches** with nearby city results — filter manually by city in the output if needed

## Files

- `master_scrape.py` — the entire tool (1200 lines, ~85 KB)
- `GUIDE_MASTER.txt` — novice-friendly user guide
- `README.md` — this file

On first run, also creates:
- `.scripts/` — extracted helper scripts (auto-managed)
- `.last_searches.json` — recent search history
- `output/` — dated folders with your Excel files
- `~/.cache/maps-session-*` / `~/.cache/jd-session-*` / etc. — persistent Chrome profiles

## Troubleshooting

See `GUIDE_MASTER.txt` for the full novice guide. Common issues:

- **"python is not recognized"** — install Python 3.11+ from python.org, check "Add to PATH"
- **JustDial blocked** — run in visible mode (option 2 at browser prompt) to warm up profile
- **Google captcha** — rare with patchright; if it happens, run in visible mode and solve manually
- **Excel file locked** — close the file in Excel before re-running
- **Slow laptop** — use single-source mode instead of "All three" (3 browsers at once eats 1.5 GB RAM)

## Credits

Built for Evara Technology's Karnataka B2B expansion plan. Mirrors Apify's
Google Maps actor output schema for drop-in CRM compatibility.
